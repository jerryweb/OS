#include "airline.h"

Airline::Airline(int id_, int ticketsIssued_, int totalBagCount_)
{
    id = id_;
    ticketsIssued = ticketsIssued_;
    totalBagCount = totalBagCount_;
}

Airline::~Airline()
{
    
}
